#include<bits/stdc++.h>
using namespace std;
int main()
{
    long long int a,l,count=0,i=1,a1,l1;

    while(cin>>a>>l)
    {
        a1=a;
        l1=l;
        if(a<0&&l<0) break;

        do
        {
            count++;
            if(a==1) break;
            else if(a%2==0) a/=2;
            else
                a=3*a+1;

        }while(a<=l);

        cout<<"Case "<<i++<<": A = "<<a1<<", limit = "<<l1<<", number of terms = "<<count<<endl;
        count=0;
    }
    return 0;
}
