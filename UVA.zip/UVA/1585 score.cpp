#include<bits/stdc++.h>
using namespace std;
int main()
{
    ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);

    int t;
    cin>>t;
    std::cin.ignore();
    while(t--){

    string s;

    int ln,c=0,sum=0;

    cin>>s;

    ln = s.length();

    for ( int i=0; i<ln; ++i)
    {
        if(s[i] == 'O') c++;

        else if(s[i] == 'X') c=0;

        sum += c;
    }
    cout<<sum<<endl;
    }
    return 0;
}
