#include<bits/stdc++.h>
using namespace std;
int main()
{
    ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    string s;
    getline(cin,s);
    int ln = s.size(),i,j;

    char c[] ={ '`', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '-', '=','Q','W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P','[', ']',  'A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L', ';', 'Z', 'X', 'C', 'V', 'B', 'N', 'M', ',', '.', '/' };

    for(i=0; i<ln; ++i)
    {
        for(j=0; j<45; ++j){
        if(s[i]=='Q' || s[i]=='A' ||s[i]=='z')continue;
        else if(s[i] == c[j]){s[i]= c[j-1];}
        }
    }
    cout<<s<<endl;

    return 0;
}
