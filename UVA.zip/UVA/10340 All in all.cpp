#include<bits/stdc++.h>
using namespace std;
int main()
{
    ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);

    string s,t;

    while(cin>>s>>t)
    {
        int i,j, c=0,n=0;

        int ls = s.size();

        int lt = t.size();

        for(i=0; i<ls; i++)
        {

            for(j=n; j<lt; j++)
            {
                if(s[i] == t[j]) {c++;n=j+1; break;}

            }

        }
        if(c==ls) cout<<"Yes"<<endl;
        else cout<<"No"<<endl;
    }

    return 0;
}
