#include<bits/stdc++.h>
using namespace std;
int main()
{
    ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    string s;
    while(1)
    {
        cin>>a;
        int len = a.length();

        string s1;
        s1 = a;
        reverse(a.begin(),a.end());

        int c=1;
        if(s1 == a)c=0;
        int cnt = 0;

        for(int i=0; i<len; i++)
        {
            if((a[i]=='A' && a[len-i-1]=='A')||(a[i]=='E' && a[len-i-1]=='3')||(a[i]=='3' && a[len-i-1]=='E')||
               (a[i]=='H' && a[len-i-1]=='H')||(a[i]=='I' && a[len-i-1]=='I')||(a[i]=='J' && a[len-i-1]=='L')||
               (a[i]=='L' && a[len-i-1]=='J')||(a[i]=='M' && a[len-i-1]=='M')||(a[i]=='O' && a[len-i-1]=='O')||
               (a[i]=='2' && a[len-i-1]=='S')||(a[i]=='T' && a[len-i-1]=='T')||(a[i]=='U' && a[len-i-1]=='U')||
               (a[i]=='V' && a[len-i-1]=='V')||(a[i]=='W' && a[len-i-1]=='W')||(a[i]=='X' && a[len-i-1]=='X')||
               (a[i]=='Y' && a[len-i-1]=='Y')||(a[i]=='Z' && a[len-i-1]=='5')||(a[i]=='5' && a[len-i-1]=='Z')||
               (a[i]=='1' && a[len-i-1]=='1')||(a[i]=='S' && a[len-i-1]=='2')||(a[i]=='8' && a[len-i-1]=='8'))
               cnt ++;
        }
        if ( c!= 0 && cnt != len){
            cout<<s1<<" -- is not a palindrome."<<endl;
        }
        else if(c == 0 && cnt != len)
        {
            cout<<s1<<" -- is a regular palindrome."<<endl;
        }
        else if(c != 0 && cnt == len){
            cout<<s1<<" -- is a mirrored string."<<endl;
        }
        else if(c == 0 && cnt == len){
            cout<<s1<<" -- is a mirrored palindrome."<<endl;
        }

    }
    return 0;
}

