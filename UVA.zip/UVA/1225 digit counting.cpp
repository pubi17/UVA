#include<bits/stdc++.h>
using namespace std;
int main()
{
    ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    int t,n,i,j,c,r,m;
    cin>>t;
    while(t--)
    {
       cin >> n;
       pair<int,int>p[10];
       for(i=0; i<=9; ++i)
       {
           p[i].first = i;
           p[i].second = 0;
       }

       for(i=1; i<=n; ++i)
       {
           if(i<10){
            p[i].second = 1;
           }
           else {
            m = i;
            while(m!=0)
            {
                r=m%10;
                m /= 10;
                p[r].second += 1;
            }
           }
       }

       for(i=0; i<9; ++i)
       {
           cout<<p[i].second<<" ";
       }
       cout<<p[9].second<<endl;
    }
    return 0;
}
