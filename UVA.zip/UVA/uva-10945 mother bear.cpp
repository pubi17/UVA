#include<bits/stdc++.h>
#include<stdio.h>
#include<string.h>
#include <ctype.h>
using namespace std;
int main()
{
    char s[500],s1[500];
    int i,j,k,d;

    while(1)
    {
        gets(s);
        d=strcmp(s,"DONE");
        if(d==0) break;

        for(i=0,j=0;s[i]!='\0';i++)
        {
if((s[i]>='a'&&s[i]<='z'))
            {
                s[j]=s[i];
                j++;
            }
            else if(s[i]>='A'&&s[i]<='Z')
            {
                s[j]=s[i]+32;
                j++;

            }

        }

        s[j]='\0';


       strcpy(s1,s);

    strrev(s);

        d=strcmp(s,s1);
        if(d==0)
        {printf("You won't be eaten!\n");}
        else{printf("Uh oh..\n");}
    }
    return 0;
}
