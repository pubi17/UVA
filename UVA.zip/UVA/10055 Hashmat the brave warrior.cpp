#include<bits/stdc++.h>
using namespace std;
int main()
{
    ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
   long long int a,b;
    while(scanf("%lld %lld",&a,&b) != EOF){
     if(a>b) swap(a,b);
    printf("%lld\n",b-a);
    }
    return 0;
}
