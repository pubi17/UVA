#include<bits/stdc++.h>
using namespace std;
int main()
{
    ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);

    int t;
    cin >> t;

    while( t --)
    {
        int G,L,a,b;
        cin >> G >> L;

         a = G;

         if ( L % G != 0) cout<< "-1" <<endl;

         else{
            b = L;
            cout<< a <<" "<< b <<endl;
         }
    }
    return 0;
}
