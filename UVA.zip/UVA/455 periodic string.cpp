#include<bits/stdc++.h>
using namespace std;
int main()
{
    ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    int t;
    cin>>t;
    cout<<endl;
    std::cin.ignore();
    while(t--)
    {
        string s;
        cin>>s;
        int ln = s.size(),i,c=0;
        for(i=1; i<ln; ++i)
        {
            if(s[0] == s[i]){c++;}
        }
        cout<<c<<endl;
    }
    return 0;
}
