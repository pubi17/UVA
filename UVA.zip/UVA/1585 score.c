#include<stdio.h>
#include<string.h>
int main()
{
    int t;
    while(scanf("%d",&t)){

    char s[100];

    int ln,c=0,sum=0;

    gets(s);

    ln = strlen(s);

    for ( int i=0; i<ln; ++i)
    {
        if(s[i] == 'O') c++;

        else if(s[i] == 'X') c=0;

        sum += c;
    }
    printf("%d\n", sum);
    }
    return 0;
}
