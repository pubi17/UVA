#include<bits/stdc++.h>
using namespace std;

int GCD ( int a, int b)
{
    if( b == 0) return a;
    return GCD (b, a%b);
}

void vector1(string str){
        vector <int> v;
        int ln = str.length(),ans=0,num=0;

    for( int i=0; i<ln; i++)
    {
        if(str[i] != ' ')
        {
             num =num*10 + (str[i] - '0');
        }
        if(str[i] == ' ' || i == ln-1)
        {
            if(num != 0){
            v.push_back(num);
            num=0;
            }
        }
    }

    for (int i=0; i<v.size(); i++)
    {
        for( int j=i+1; j<v.size(); j++)
        {
            ans = max(ans,GCD(v[i],v[j]));

        }
    }
cout << ans << endl;

    }

    int main()
    {
        ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
        int t;
        cin >> t;
        std::cin.ignore();
        for (int i=1; i<=t; ++i){

            string s;

            getline(cin,s);

            vector1(s);
        }
     return 0;
    }

