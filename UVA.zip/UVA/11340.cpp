#include<bits/stdc++.h>
using namespace std;
int main()
{
    ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    int t,k,i,j,n,ln;
    char c;
    string line;
    double v,sum=0;
    map<char,double>m;
    map<char,double>::iterator it;
    cin>>t;
    cin.ignore();
    while(t--)
    {
        cin>>k;
        for(i=0; i<k; ++i){
            cin>>c>>v;
            m[c] = v;
        }
        cin>>n;
        cin.ignore();
        for(i=0; i<n; ++i)
        {
            getline(cin,line);
            ln = line.size();

            for(j=0; j<ln; ++j)
            {
                it = m.find(line[j]);
                if(it != m.end()) sum += it->second;
            }
        }
        sum /= 100;
        cout<<fixed<<setprecision(2)<<sum<<"$"<<endl;
        sum=0;
        m.clear();
    }
    return 0;
}
