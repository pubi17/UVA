#include<bits/stdc++.h>
using namespace std;
int main()
{
    int a[10005],n,t,i,j;
    ios::sync_with_stdio(0);
    cin>>t;
    for(j=1;j<=t;j++)
    {
        cin>>n;
        for(i=1;i<=n;i++)
        {
            cin>>a[i];
        }
        int max=a[1];
        for(i=1;i<=n;i++)
        {
            if(max<a[i])
                max=a[i];
        }
        cout<<"Case "<<j<<": "<<max<<endl;
    }
    return 0;
}
