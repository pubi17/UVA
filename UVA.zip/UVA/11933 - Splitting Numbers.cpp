#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
int main()
{
    ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    cout << fixed << setprecision(10);

    unsigned int num;
    while(1){
    cin >> num; if(num==0) break;

    unsigned int a = 0, b = 0, add=1;
    if(num&1) {a=1; b=num-1;}
    else {a=2; b=num-2;}


    cout << a << ' ' << b << endl;

    }
    return 0;
}
